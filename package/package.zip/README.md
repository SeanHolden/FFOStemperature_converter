FFOStemperature_converter
=========================

First app for Firefox OS. Celcius / Farenheit converter.
